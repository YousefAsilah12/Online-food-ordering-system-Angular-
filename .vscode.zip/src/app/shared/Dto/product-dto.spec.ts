import { ProductDto } from './product-dto';

describe('ProductDto', () => {
  it('should create an instance', () => {
    expect(new ProductDto()).toBeTruthy();
  });
});
