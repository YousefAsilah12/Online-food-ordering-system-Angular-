import { CPDemo } from './c-p-demo';

describe('CPDemo', () => {
  it('should create an instance', () => {
    expect(new CPDemo()).toBeTruthy();
  });
});
