import { Cities } from './cities';

describe('Cities', () => {
  it('should create an instance', () => {
    expect(new Cities()).toBeTruthy();
  });
});
