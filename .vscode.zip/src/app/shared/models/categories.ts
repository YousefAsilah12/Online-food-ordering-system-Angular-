export class Categories {
  id?:number;
  firstName?:string;
  image?:string;
  productDescription?:string;

}
