export class Suppliers {
  id ? : string;
  image ? : string;
  companyTitle ? : string;
  companyName ? : string;
  adreass ? : string;
  phone ? : string;
  fax ? : string;
  email ? : string;
}
