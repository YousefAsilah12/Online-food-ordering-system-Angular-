import { Suppliers } from './suppliers';

describe('Suppliers', () => {
  it('should create an instance', () => {
    expect(new Suppliers()).toBeTruthy();
  });
});
