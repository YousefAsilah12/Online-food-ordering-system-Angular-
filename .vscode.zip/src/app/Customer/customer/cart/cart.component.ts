import { CartService } from './../../../shared/services/cart.service';
import { Cart } from './../../../shared/models/cart';
import { CustomerProductsService } from './../../../shared/services/customer-products.service';
import { OrderService } from './../../../shared/services/order.service';
import { Router } from '@angular/router';
import {
  CPDemo
} from './../../../shared/models/c-p-demo';
import {
  Component,
  OnInit
} from '@angular/core';
import {
  PrimeNGConfig
} from 'primeng/api';
import {ConfirmationService} from 'primeng/api';
import {Message} from 'primeng/api';
import { CustomerService } from 'src/app/shared/services/customer.service';
import { Customer } from 'src/app/shared/models/customer';



@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {
  msgs: Message[] = [];

  products: CPDemo[];
  cartproduct: CPDemo[];

  //user logged in
  user:Customer
  //id for saving to local storage
  id :string
  constructor(private CartService:CartService
              ,private confirmationService: ConfirmationService,
              private OrderService:OrderService,
             private primengConfig: PrimeNGConfig
              ,private cs :CustomerService,
              private CustomerProductsServ:CustomerProductsService
              ,private router:Router) {}


  deleteprod(id:number){
    debugger
    this.cartproduct = JSON.parse(localStorage.getItem(this.id));
    var result = this.cartproduct.findIndex(x => parseInt(x.product.id)  == id);
    if (result > -1) {
      // delete this.cartproduct[result];
      this.cartproduct.splice(result, 1);
      localStorage.setItem(this.id, JSON.stringify(this.cartproduct));
      this.products = JSON.parse(localStorage.getItem(this.id));
      window.location.reload();

    }


  }

  productPlus(id: number) {
    this.cartproduct = JSON.parse(localStorage.getItem(this.id));
    var result = this.cartproduct.findIndex(x => parseInt( x.product.id) == id);
    if (result != -1) {
      if (this.cartproduct[result].quantityToOrder < 10) {
        this.cartproduct[result].quantityToOrder++;
        localStorage.setItem(this.id, JSON.stringify(this.cartproduct))
        this.products = JSON.parse(localStorage.getItem(this.id));
        window.location.reload();

      } else {
        alert('you cant add more than 10 items ')
      }
    }
  }


  productMinus(id: number) {
    this.cartproduct = JSON.parse(localStorage.getItem(this.id));
    var result = this.cartproduct.findIndex(x => parseInt(x.product.id )== id);
    console.log(result)
    if (result != -1) {
      if (this.cartproduct[result].quantityToOrder > 0) {
        this.cartproduct[result].quantityToOrder--;
        localStorage.setItem(this.id, JSON.stringify(this.cartproduct))
        this.products = JSON.parse(localStorage.getItem(this.id));
        window.location.reload();
      }
    }
  }
  async ngOnInit() {

    this.user= await this.cs.getCustomer();
    this.id=this.user.id.toString()
    this.products = JSON.parse(localStorage.getItem(this.id));
    console.log(this.products);
    this.primengConfig.ripple = true;
  }


  async checkOut(){
    var a = {
      customerId:this.user.id,
      frieght:0
    }

    try {
      var s = await this.OrderService.addItem(a);
      //save order id to use it in  cart table and customerProduct
      this.OrderService.orderId=s.id;
      console.log('order : ', s)

    } catch (error) {
      alert('cannot Create  this orders ! ')
    }


    //then we create the cart table
    try {
      var cartc= {
        totalAmount:0,
        orderId:this.OrderService.orderId,
        paymentType:"cash",
        tax:0.17
      }

      var resCart=await this.CartService.addItem(cartc);
      console.log( 'cart :' ,resCart)
      //also we save product id in service to user it

      this.CartService.cartId=resCart.id;

    } catch (error) {
console.log('cannot Creat Cart ')
    }


    try {
      debugger
      //send customer products to the customer product table
      for (let index = 0; index < this.products.length; index++) {
        var cp={
          cartId:this.CartService.cartId,
          orderId:this.OrderService.orderId,
          productId:this.products[index].product.id,
          quantity:this.products[index].quantityToOrder
        }

       var res= await this.CustomerProductsServ.addItem(cp)
       console.log(res)
      }
      this.CartService.cartId=null;
      this.OrderService.orderId=null;

    } catch (error) {
      console.log('error while upploading products (customerProduct error)')
    }
  }
}
