import { CategorieService } from './../../../shared/services/categorie.service';
import { Categories } from './../../../shared/models/categories';
import { ProductsService } from './../../../shared/services/products.service';
import { Router } from '@angular/router';
import { Products } from './../../../shared/models/products';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public products: Products[];
  public categories: Categories[];

	responsiveOptions;

  travel(){
    this.router.navigate(["./Customer/products"])

  }
  constructor(private appHttp: ProductsService,
    private router:Router,
    private prodservice:ProductsService,
    private catService:CategorieService) {
      this.responsiveOptions = [
        {
            breakpoint: '1024px',
            numVisible: 3,
            numScroll: 3
        },
        {
            breakpoint: '768px',
            numVisible: 2,
            numScroll: 2
        },
        {
            breakpoint: '560px',
            numVisible: 1,
            numScroll: 1
        }
    ];


   }

   async ngOnInit() {

     this.products= await this.prodservice.getAll();
     this.categories=await this.catService.getAll();


    }}
