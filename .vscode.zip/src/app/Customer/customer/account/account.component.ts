import { Router } from '@angular/router';
import { CustomerService } from 'src/app/shared/services/customer.service';
import { Customer } from './../../../shared/models/customer';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {


  public user:Customer;

  constructor(public Customerserv:CustomerService,
              public router:Router) { }

  async ngOnInit() {
    this.user=await this.Customerserv.getCustomer();
  }

}
