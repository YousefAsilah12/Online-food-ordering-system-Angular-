import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/shared/services/customer.service';
import { Customer } from './../../../shared/models/customer';
import { Component, OnInit } from '@angular/core';
import {ConfirmationService, MessageService} from 'primeng/api';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class RegisterComponent implements OnInit {




  base="https://localhost:44318/api/Customers/";

  passwrod:string;
  firstName:string;
  lastname:string;
  Date:Date;
  phone:string;
  homenum:number;
  street:string;
  city:string;
  email:string;




  cities:string[];

  //to change template
  templateChange="home";
  tempbool=true;
  tt:string='true'
   constructor(
     private confirmationService: ConfirmationService,
                private CustomerService:CustomerService,
                private Router:Router
                ,private http:HttpClient) {

     this.cities=[
      'jerusalem',
      "haifa",
      "yafa"
    ];


  }

   loginProces(){

   }

   change(data :string){
     if(data=='profile'){
      this.templateChange='profile';
      this.tempbool=true;
     }else{
       this.templateChange='home';
       this.tempbool=false;

     }

   }
   makeCustomer(){
     var customer:Customer={};
    customer.firstName=this.firstName;
    customer.lastName=this.lastname;
    customer.image="https://www.freeiconspng.com/uploads/no-image-icon-4.png";
    customer.password=this.passwrod;
    customer.birthdate=this.Date;
    customer.phone=this.phone;
    customer.email=this.email;
    customer.homeNo=this.homenum;
    customer.stret=this.street;
    customer.city=this.city;
    return customer;
   }
  ngOnInit(): void {
    this.change(this.templateChange);
  }
  async confirm(event: Event) {
    this.confirmationService.confirm({
        target: event.target,
        message: 'to continue to login ?',
        icon: 'pi pi-user-plus',
        accept: () => {
           var res:Customer=this.makeCustomer();
          if (res) {
             var result=this.CustomerService.postuser(res);
             if (result) {
              console.log(result)
              this.Router.navigate(['/login'])

             }
             else{
               alert('wrong!')
             }
          }
        },
        reject: () => {
          this.Router.navigate(['/login/register']);
          alert("try again ")
        }
    });
}
}
