import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar-slim',
  templateUrl: './nav-bar-slim.component.html',
  styleUrls: ['./nav-bar-slim.component.css']
})
export class NavBarSlimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
