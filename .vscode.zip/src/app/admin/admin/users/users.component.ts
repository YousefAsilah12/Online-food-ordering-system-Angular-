import { CustomerService } from './../../../shared/services/customer.service';
import { Customer } from './../../../shared/models/customer';
import {
  Component,
  OnInit
} from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
interface City {
  name: string
}
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})

export class UsersComponent implements OnInit {



customerDialog: boolean;

customers: Customer[];

 customer:Customer;

  selectedCustomers: Customer[];

  submitted: boolean;

  statuses: boolean[];


  cities: City[];
  selectedCity: City;



  invalidDates: Array<Date>
  date6: Date;

  constructor( private CustomerService: CustomerService,
     private messageService: MessageService,
      private confirmationService: ConfirmationService) {
        this.cities = [
          {name: 'New York'},
          {name: 'Rome'},
          {name: 'London'},
          {name: 'Istanbul'},
          {name: 'Paris'}
      ];
      }

  async ngOnInit() {
    this.customers = await this.CustomerService.getAll();
    console.log(this.customers)

    this.statuses = [true, false];



  }
  openNew() {
    this.customer = {};
    this.submitted = false;
    this.customerDialog = true;
  }

  deleteSelectedCustomers() {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete the selected customers?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        this.customers = this.customers.filter(val => !this.selectedCustomers.includes(val));
        for (let index = 0; index < this.selectedCustomers.length; index++) {
          await this.CustomerService.deleteItem (this.selectedCustomers[index].id)

        }
        this.customers=await this.CustomerService.getAll();

        this.selectedCustomers = null;
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'customers Deleted',
          life: 3000
        });
      }
    });
  }

  editCustomer(customer: Customer) {
    this.customer = {
      ...customer
    };
    this.customerDialog = true;
  }

  async deleteCustomer(customer: Customer) {
    debugger
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + customer.firstName+' '+customer.lastName + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        // this.Customers = this.Customers.filter(val => val.id !==customer.id);
        await this.CustomerService.deleteItem(customer.id)
        this.customers=await this.CustomerService.getAll();
         this.customer = {};
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'customer Deleted',
          life: 3000
        });
      }
    });
  }

  hideDialog() {
    this.customerDialog = false;
    this.submitted = false;
  }

  getSupplierIdByName(name: string) {

  }

  async saveCustomer() {
    debugger
    this.submitted = true;
    this.customer.birthdate=this.date6;
    this.customer.city=this.selectedCity.name;
    console.log(this.customer)
    if (this.customer.id) {
      await this.CustomerService.PutCustomer(this.customer, this.customer.id)
      this.customers = await this.CustomerService.getAll();

      this.messageService.add({
        severity: 'success',
        summary: 'Successful',
        detail: 'Customer Updated',
        life: 3000
      });
    } else {
      this.customer.image = 'https://png.pngtree.com/png-vector/20190525/ourlarge/pngtree-man-avatar-icon-professional-man-character-png-image_1055448.jpg';
      await this.CustomerService.postuser(this.customer)
      this.customers = await this.CustomerService.getAll();

      this.messageService.add({
        severity: 'success',
        summary: 'Successful',
        detail: 'Customer Created',
        life: 3000
      });
    }

    this.customers = [...this.customers];
    this.customerDialog = false;
    this.customer = {};
  }
  createId()  {
    let id = '';
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (var i = 0; i < 5; i++) {
      id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return id;
  }

}










