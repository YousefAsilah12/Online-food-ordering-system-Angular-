import { SuppliersService } from 'src/app/shared/services/suppliers.service';
import { Suppliers } from 'src/app/shared/models/suppliers';
import { Component, OnInit } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-suppliers',
  templateUrl: './suppliers.component.html',
  styleUrls: ['./suppliers.component.css']
})
export class SuppliersComponent implements OnInit {

  supplierDialog: boolean;

  suppliers: Suppliers[];

  supplier: Suppliers;

  selectedsuppliers: Suppliers[];

  submitted: boolean;

  statuses: boolean[];





  constructor( private SupplierService: SuppliersService, private messageService: MessageService, private confirmationService: ConfirmationService) {}

  async ngOnInit() {
    this.suppliers = await this.SupplierService.getAll();
    console.log(this.suppliers)

    this.statuses = [true, false]

  }
  openNew() {
    this.supplier ={};
    this.submitted = false;
    this.supplierDialog = true;
  }

  deleteSelectedsuppliers() {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete the selected suppliers ?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        this.suppliers = this.suppliers.filter(val => !this.selectedsuppliers.includes(val));
        for (let index = 0; index < this.selectedsuppliers.length; index++) {
          await this.SupplierService.deleteItem(parseInt(this.selectedsuppliers[index].id) )

        }
        this.suppliers=await this.SupplierService.getAll();

        this.selectedsuppliers = [{}];
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'supplier Deleted',
          life: 3000
        });
      }
    });
  }

  editsupplier(supplier: Suppliers) {
    console.log(supplier)
    this.supplier = {
      ...supplier
    };
    this.supplierDialog = true;
  }

  async deletesupplier(supplier: Suppliers) {
    debugger
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + supplier.companyTitle +' '+supplier.companyName+  '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        // this.products = this.products.filter(val => val.id !== product.id);
        await this.SupplierService.deleteItem( parseInt(supplier.id))
        this.suppliers=await this.SupplierService.getAll();
         this.supplier = {};
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'supplier Deleted',
          life: 3000
        });
      }
    });
  }

  hideDialog() {
    this.supplierDialog = false;
    this.submitted = false;
  }


  async savesupplier() {
    debugger
    console.log(this.supplier)
    console.log(this.supplier.id)
    this.submitted = true;


    if (this.supplier.id) {
      await this.SupplierService.updateItem(this.supplier, parseInt(this.supplier.id))
      this.suppliers = await this.SupplierService.getAll();

      this.messageService.add({
        severity: 'success',
        summary: 'Successful',
        detail: 'supplier Updated',
        life: 3000
      });
    } else {
      // this.product.image = 'product-placeholder.svg';
     this.supplier.image= "https://st4.depositphotos.com/14953852/24787/v/600/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg";

      await this.SupplierService.addItem(this.supplier)
      this.suppliers = await this.SupplierService.getAll();

      this.messageService.add({
        severity: 'success',
        summary: 'Successful',
        detail: 'supplier Created',
        life: 3000
      });
    }

    this.suppliers = [...this.suppliers];
    this.supplierDialog = false;
    this.supplier = {};
  }


}
