import { Products } from './../../../shared/models/products';
import { Component, OnInit } from '@angular/core';
import { MessageService, ConfirmationService, SelectItem } from 'primeng/api';
import { Categories } from 'src/app/shared/models/categories';
import { Suppliers } from 'src/app/shared/models/suppliers';
import { CategorieService } from 'src/app/shared/services/categorie.service';
import { ProductsService } from 'src/app/shared/services/products.service';
import { SuppliersService } from 'src/app/shared/services/suppliers.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  providers: [MessageService, ConfirmationService]

})
export class ProductsComponent implements OnInit {

  slectedCategory: Categories;
  selectedSupplier: Suppliers;

  productDialog: boolean;
  DiscountDialog: boolean;
  DiscountDialog2:boolean;
  products: Products[];
  productsInSale: Products[];


  product: Products;

  selectedProducts: Products[];
  selectedProductsDiscount: Products[];

  submitted: boolean;

  statuses: boolean[];

  suppliers: Suppliers[];

  categories: Categories[];

  discount:number
  selectedCategory


  constructor(private SupplierService: SuppliersService, private CategoryService: CategorieService, private productService: ProductsService, private messageService: MessageService, private confirmationService: ConfirmationService) {}

  async ngOnInit() {
    this.products = await this.productService.getAll();
    this.categories = await this.CategoryService.getAll();
    this.suppliers = await this.SupplierService.getAll();
    console.log(this.products)
    console.log(this.categories)
    console.log(this.suppliers)

    this.statuses = [true, false]

  }
  openNew() {
    this.product = {};
    this.submitted = false;
    this.productDialog = true;
  }

  openDiscount(){
    this.product = {};
    this.submitted = false;
    this.DiscountDialog = true;

  }
  openDiscount2(){
    this.product = {};
    this.submitted = false;
    this.DiscountDialog2 = true;

  }


  deleteSelectedProducts() {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete the selected products?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        this.products = this.products.filter(val => !this.selectedProducts.includes(val));
        for (let index = 0; index < this.selectedProducts.length; index++) {
          await this.productService.deleteItem(parseInt(this.selectedProducts[index].id))

        }
        this.products=await this.productService.getAll();

        this.selectedProducts = null;
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'Products Deleted',
          life: 3000
        });
      }
    });
  }

  editProduct(product: Products) {
    this.product = {
      ...product
    };
    this.productDialog = true;
  }

  async deleteProduct(product: Products) {
    debugger
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + product.productName + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        // this.products = this.products.filter(val => val.id !== product.id);
        await this.productService.deleteItem(parseInt(product.id))
        this.products=await this.productService.getAll();
         this.product = {};
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'Product Deleted',
          life: 3000
        });
      }
    });
  }

  hideDialog() {
    this.productDialog = false;
    this.submitted = false;
  }
  hideDiscountDialog() {
    this.DiscountDialog = false;
    this.submitted = false;
  }
  hideDiscountDialog2() {
    this.DiscountDialog2 = false;
    this.submitted = false;
  }


  getSupplierIdByName(name: string) {

  }

  async saveProduct() {
    debugger
    this.product.categoryId = this.slectedCategory.id;
    this.product.supplierId = parseInt(this.selectedSupplier.id);
    this.submitted = true;
    var post = {
      supplierId: this.product.supplierId,
      categoryId: this.product.categoryId,
      serialNumber: this.product.serialNumber,
      ProductName: this.product.productName,
      image: "product-placeholder.svg",
      active: Boolean(this.product.active),
      discount: this.product.discount,
      stockQuanitity: this.product.stockQuanitity,
      ProductDescription: this.product.productDescription

    }


    console.log(post)
    if (this.product.id) {
      await this.productService.updateItem(post, parseInt(this.product.id))
      this.products = await this.productService.getAll();

      this.messageService.add({
        severity: 'success',
        summary: 'Successful',
        detail: 'Product Updated',
        life: 3000
      });
    } else {
      // this.product.image = 'product-placeholder.svg';
      post.serialNumber=this.createId();
      await this.productService.addItem(post)
      this.products = await this.productService.getAll();

      this.messageService.add({
        severity: 'success',
        summary: 'Successful',
        detail: 'Product Created',
        life: 3000
      });
    }

    this.products = [...this.products];
    this.productDialog = false;
    this.product = {};
  }
  createId()  {
    let id = '';
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (var i = 0; i < 5; i++) {
      id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return id;
  }

  //it update the product if active or Not ...
  productfalse(){
    this.product.active=false;
  }
  productTrue(){
    this.product.active=true;

  }

  //its will post or Remove the item from the customer Page
  async EditProductStatus(product:Products){
    console.log(product)

    if (product.active==true) {
      this.confirmationService.confirm({
        message: 'Are you sure you  to publish this product ' + product.productName + '?',
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: async () => {
          product.active=false
          await this.productService.updateItem(product, parseInt(product.id))
          this.products = await this.productService.getAll();
              this.messageService.add({
            severity: 'success',
            summary: 'Successful',
            detail: 'Product Deleted',
            life: 3000
          });
        }
      });

    }
    else{
      this.confirmationService.confirm({
        message: 'Are you sure you  to disable  this product ' + product.productName + '?',
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: async () => {
          product.active=true

          await this.productService.updateItem(product, parseInt(product.id))
          this.products = await this.productService.getAll();
              this.messageService.add({
            severity: 'success',
            summary: 'Successful',
            detail: 'Product Deleted',
            life: 3000
          });
        }
      });

    }




  }

  discountfunction(){
debugger
    // if we have selected item we open template #1
    // else we Open #2 template (other Template ).
    if (this.selectedProducts) {
      this.openDiscount();
    }
    else{
          //first get the items are on Sale
    for (let index = 0; index < this.products.length; index++) {
      if (this.products[index].discount >0 ) {
        this.productsInSale.push(this.products[index])

      }

     }

      this.openDiscount2();
    }
    // this.products = [...this.products];
    // this.DiscountDialog = false;
    // this.product = {};

  }

  SaveDiscount(){
    this.confirmationService.confirm({
      message: 'Are you sure you want to Add Discountfor the selected products?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        this.products = this.products.filter(val => !this.selectedProducts.includes(val));
        for (let index = 0; index < this.selectedProducts.length; index++) {
          this.selectedProducts[index].discount=this.discount
          await this.productService.updateItem(this.selectedProducts[index], parseInt(this.selectedProducts[index].id))

        }
        this.hideDiscountDialog();
        this.products=await this.productService.getAll();

        this.selectedProducts = null;
        this.discount=null;
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'Discount added ! ',
          life: 3000
        });
      }
    });

  }


  async removeDiscount(){

    if (this.productsInSale) {
      console.log("items on sale " + this.productsInSale)

      this.confirmationService.confirm({
        message: 'Are you sure you want to Add Discountfor the selected products?',
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: async () => {
          this.products = this.products.filter(val => !this.selectedProducts.includes(val));
          for (let index = 0; index < this.productsInSale.length; index++) {
            this.productsInSale[index].discount=0;
            await this.productService.updateItem(this.productsInSale[index],parseInt(this.productsInSale[index].id))
          }
          this.hideDiscountDialog2();
          this.products=await this.productService.getAll();

          this.selectedProducts = null;
          this.discount=null;
          this.messageService.add({
            severity: 'success',
            summary: 'Successful',
            detail: 'Discount added ! ',
            life: 3000
          });
        }
      });

    }


  }
}
