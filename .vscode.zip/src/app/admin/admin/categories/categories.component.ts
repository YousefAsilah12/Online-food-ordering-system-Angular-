import { Categories } from './../../../shared/models/categories';
import { Component, OnInit } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { CategorieService } from 'src/app/shared/services/categorie.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css'],
  providers: [MessageService, ConfirmationService]

})
export class CategoriesComponent implements OnInit {


  categoryDialog: boolean;

  categories: Categories[];

  category: Categories;

  selectedCategories: Categories[];

  submitted: boolean;

  statuses: boolean[];





  constructor( private CategoryService: CategorieService, private messageService: MessageService, private confirmationService: ConfirmationService) {}

  async ngOnInit() {
    this.categories = await this.CategoryService.getAll();
    console.log(this.categories)

    this.statuses = [true, false]

  }
  openNew() {
    this.category ={};
    this.submitted = false;
    this.categoryDialog = true;
  }

  deleteSelectedCategories() {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete the selected categories ?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        this.categories = this.categories.filter(val => !this.selectedCategories.includes(val));
        for (let index = 0; index < this.selectedCategories.length; index++) {
          await this.CategoryService.deleteItem(this.selectedCategories[index].id)

        }
        this.categories=await this.CategoryService.getAll();

        this.selectedCategories = [{}];
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'category Deleted',
          life: 3000
        });
      }
    });
  }

  editCategory(category: Categories) {
    console.log(category)
    this.category = {
      ...category
    };
    this.categoryDialog = true;
  }

  async deleteCategory(category: Categories) {
    debugger
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + category.firstName + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        // this.products = this.products.filter(val => val.id !== product.id);
        await this.CategoryService.deleteItem(category.id)
        this.categories=await this.CategoryService.getAll();
         this.category = {};
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'category Deleted',
          life: 3000
        });
      }
    });
  }

  hideDialog() {
    this.categoryDialog = false;
    this.submitted = false;
  }


  async saveCategory() {
    debugger
    console.log(this.category.id)
    this.submitted = true;
    var post = {
      firstName: this.category.firstName,
      productDescription:this.category.productDescription,
      image:this.category.image

    }


    console.log(post)
    if (this.category.id) {
      await this.CategoryService.updateItem(post, this.category.id)
      this.categories = await this.CategoryService.getAll();

      this.messageService.add({
        severity: 'success',
        summary: 'Successful',
        detail: 'Category Updated',
        life: 3000
      });
    } else {
      // this.product.image = 'product-placeholder.svg';
      post.image= "https://st4.depositphotos.com/14953852/24787/v/600/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg";

      await this.CategoryService.addItem(post)
      this.categories = await this.CategoryService.getAll();

      this.messageService.add({
        severity: 'success',
        summary: 'Successful',
        detail: 'category Created',
        life: 3000
      });
    }

    this.categories = [...this.categories];
    this.categoryDialog = false;
    this.category = {};
  }

}
