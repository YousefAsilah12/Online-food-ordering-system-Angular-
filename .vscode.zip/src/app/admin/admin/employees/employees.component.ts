import { EmployeeService } from './../../../shared/services/employee.service';
import { Employee } from './../../../shared/models/employee';
import { Component, OnInit } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { DatePipe } from '@angular/common';
interface role{
  name:string;
}

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css'],
  providers: [DatePipe]
})
export class EmployeesComponent implements OnInit {

  employeeDialog: boolean;

  employees: Employee[];

  employee:Employee;

    selectedemployees: Employee[];

    submitted: boolean;

    statuses: boolean[];



  roles:role[];
  selectedRole:role;
    invalidDates: Array<Date>
    birthDate: Date;
    hireDate: Date;
    myDate = new Date();
    constructor( private employeeService: EmployeeService,
       private messageService: MessageService,
        private confirmationService: ConfirmationService,
        private datePipe: DatePipe) {
          this.roles = [
           {name:"Admin"},
           {name:"Employee"},

         ];
        //  this.date = this.datePipe.transform(this.hireDate, 'yyyy-MM-dd');
        }

    async ngOnInit() {
      this.employees = await this.employeeService.getAll();
      console.log(this.employees)

      this.statuses = [true, false];
      var a = new Date
      console.log(a)


    }
    openNew() {
      this.employee = {};
      this.submitted = false;
      this.employeeDialog = true;
    }

    deleteSelectedEmployees() {
      debugger
      this.confirmationService.confirm({
        message: 'Are you sure you want to delete the selected employees?',
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: async () => {
          this.employees = this.employees.filter(val => !this.selectedemployees.includes(val));
          for (let index = 0; index < this.selectedemployees.length; index++) {
            await this.employeeService.deleteItem (this.selectedemployees[index].id)

          }
          this.employees=await this.employeeService.getAll();

          this.selectedemployees = null;
          this.messageService.add({
            severity: 'success',
            summary: 'Successful',
            detail: 'employee Deleted',
            life: 3000
          });
        }
      });
    }

    editEmployee(employee: Employee) {
      this.employee = {
        ...employee
      };
      this.employeeDialog = true;
    }

    async deleteEmployee(employee: Employee) {
      debugger
      this.confirmationService.confirm({
        message: 'Are you sure you want to delete ' + employee.firstName+' '+employee.lastName + '?',
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: async () => {
          // this.Employees = this.Employees.filter(val => val.id !==Employee.id);
          await this.employeeService.deleteItem(employee.id)
          this.employees=await this.employeeService.getAll();
           this.employee = {};
          this.messageService.add({
            severity: 'success',
            summary: 'Successful',
            detail: 'employee Deleted',
            life: 3000
          });
        }
      });
    }

    hideDialog() {
      this.employeeDialog = false;
      this.submitted = false;
    }


    async saveEmployee() {
      debugger
      this.submitted = true;
      this.employee.birthDate=this.birthDate;
      this.employee.role=this.selectedRole.name;
      //this.Employee.city=this.selectedCity.name;
      console.log(this.employee)
      if (this.employee.id) {
        this.employee.hireDate=this.hireDate;
        await this.employeeService.PutEmployee(this.employee, this.employee.id)
        this.employees = await this.employeeService.getAll();

        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'employee Updated',
          life: 3000
        });
      } else {

        this.employee.hireDate=this.myDate;
        this.employee.image = 'https://png.pngtree.com/png-vector/20190525/ourlarge/pngtree-man-avatar-icon-professional-man-character-png-image_1055448.jpg';
        await this.employeeService.postuser(this.employee)
        this.employees = await this.employeeService.getAll();

        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'employee Created',
          life: 3000
        });
      }

      this.employees = [...this.employees];
      this.employeeDialog = false;
      this.employee = {};
    }

}
