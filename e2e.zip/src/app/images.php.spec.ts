import { Images.Php } from './images.php';

describe('Images.Php', () => {
  it('should create an instance', () => {
    expect(new Images.Php()).toBeTruthy();
  });
});
