export class Auth {
  email:string;
  password:string;
}
