export class CustomerProduct {
  cartId:number;
  orderId:number;
  productId:number;
  quantity:number;
}
