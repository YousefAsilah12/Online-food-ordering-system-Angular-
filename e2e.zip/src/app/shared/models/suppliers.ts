export class Suppliers {
  id ? : string;
  image ? : string;
  companyTitle ? : string;
  companyName ? : string;
  Address ? : string;
  phone ? : string;
  fax ? : string;
  email ? : string;
}
