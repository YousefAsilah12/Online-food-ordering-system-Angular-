import { Products } from 'src/app/shared/models/products';
export class CPDemo {
  product?:Products;
  quantityToOrder?:number;


//   constructor(  productId:number,quantity=1){
//     this.productId=productId;
//     this.quantity=quantity;

//   }
}
