import { CustomerProducts } from './customer-products';

describe('CustomerProducts', () => {
  it('should create an instance', () => {
    expect(new CustomerProducts()).toBeTruthy();
  });
});
