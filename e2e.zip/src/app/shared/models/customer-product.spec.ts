import { CustomerProduct } from './customer-product';

describe('CustomerProduct', () => {
  it('should create an instance', () => {
    expect(new CustomerProduct()).toBeTruthy();
  });
});
