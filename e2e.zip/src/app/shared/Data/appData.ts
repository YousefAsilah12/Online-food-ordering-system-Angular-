export class siteInfo {
    name:string;
    Logo:string
    Description:string;

    IsExist:boolean;
};



export const site:siteInfo = {
  name: 'StudioHatnaResturantDb',
  Logo: "https://i.ibb.co/X2SVmbV/lastsmalllogo.png",
  IsExist: true,
  Description: ""
}

export class Links{
  facebook: string;
  Instagram: string;
  youtube:string;
  twitter:string;
}

export class images{
  LoginPageImage:string;

}
