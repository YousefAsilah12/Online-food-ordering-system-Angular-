import { CustomerDto } from './customer-dto';

describe('CustomerDto', () => {
  it('should create an instance', () => {
    expect(new CustomerDto()).toBeTruthy();
  });
});
