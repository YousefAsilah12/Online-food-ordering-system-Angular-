import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-dto',
  templateUrl: './customer-dto.component.html',
  styleUrls: ['./customer-dto.component.css']
})
export class CustomerDtoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
