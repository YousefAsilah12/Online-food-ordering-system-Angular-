export class CustomerDto {
  firstName?:string;
  lastName?:string;
  image?:string;
  password?:string;
  birthdate?:Date;
  phone?:string;
  email?:string;
  homeNo?:number;
  street?:string;
  city?:string;
  }
