import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-password-changed',
  templateUrl: './password-changed.component.html',
  styleUrls: ['./password-changed.component.css']
})
export class PasswordChangedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
