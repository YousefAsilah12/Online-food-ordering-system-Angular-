import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerlayout',
  templateUrl: './customerlayout.component.html',
  styleUrls: ['./customerlayout.component.css']
})
export class CustomerlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
